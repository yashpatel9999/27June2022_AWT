function changefont(){
	document.getElementById("hone").style.fontFamily="newfont";	
}

function changesize(){
	document.getElementById("hone").style.fontSize="50px";	
}

function hide(){
	document.getElementById("hone").style.display=none;	
}