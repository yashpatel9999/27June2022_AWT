function alertjs1(){
	alert('hii guys');
	document.get1ElementById('a').style.backgroundcolor="blue";
}
function confirmjs1(){
	confirm('hii guys');
	document.get1ElementById('b').style.backgroundcolor="red";
}
function promptjs1(){
	prompt('hii guys');
	document.get1ElementById('c').style.backgroundcolor=prompt('enter color');
}
	function externalochange(){
		document.body.style.backgroundcolor=document.getElementById('cb1').ariaValue;
	}
	console.log('hii');